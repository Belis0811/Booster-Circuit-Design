//////////////////////////////////////////////////////////////////////////////////	 
//1.8��SPI����TFTҺ������
//Ƕ��ʽ�������̳ǵ�
//�Ա���վ��http://mcudev.taobao.com
//�汾��V1.1
//All rights reserved
//////////////////////////////////////////////////////////////////////////////////	

//==================================����л���������ʾ=======================================//
//��Lcd_Driver.hͷ�ļ����޸ĺ�#define USE_HORIZONTAL ֵΪ0ʹ������ģʽ.1,ʹ�ú���ģʽ
//===========================����л�ģ��SPI����������Ӳ��SPI��������=========================//
//��Lcd_Driver.hͷ�ļ����޸ĺ�#define USE_HARDWARE_SPI  ֵΪ0ʹ��ģ��SPI����.1,ʹ��Ӳ��SPI����


/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
#include "Lcd_Driver.h"
#include "LCD_Config.h"
#include "GUI.h"
#include "delay.h"
#include "Picture.h"
#include "stm32f10x_gpio.h"
#include "LED.h"
#include "key.h"
#include "usart.h"
#include "adc.h"
#include "stm32f10x_adc.h"
#include "misc.h"
#include "beep.h"
#include "relay.h"

GPIO_InitTypeDef GPIO_InitStructure;


void RCC_Configuration(void);

void Delayms(__IO uint32_t nCount);





void Name(void)
{

	Lcd_Clear(GRAY0);
	

	Gui_DrawFont_GBK16(0,10,BLACK,GRAY0,"�����ǳ̰���");
	Gui_DrawFont_GBK16(0,55,BLACK,GRAY0,"�༶��34071802");
	Gui_DrawFont_GBK16(0,100,BLACK,GRAY0,"ѧ����2018214934");
  
	delay_ms(3600);


}


void Website(void)
{
	Lcd_Clear(GRAY0);
	Gui_DrawFont_GBK16(0,50,BLUE,GRAY0,"www.cqupt.edu.cn");


	delay_ms(3600);	
}


//16λ ��ֱɨ��  �ҵ���  ��λ��ǰ
void show_pic(void)
{
	int i,j,k;
	unsigned char picH,picL;
	
	Lcd_Clear(GRAY0);
	


	{
			k=0;
			for(i=0;i<128;i++)
			for(j=0;j<160;j++)
			{
				picH=gImage_xiaohui[k++];
				picL=gImage_xiaohui[k++];
				Lcd_WriteData(picH);
				Lcd_WriteData(picL);
				
				
			}			
	}	

		
delay_ms(3600);		
} 
void show_photo(void)
{
	int i,j,k;
	unsigned char picH2,picL2;
	
	Lcd_Clear(GRAY0);
	


	{
			k=0;
			for(i=0;i<128;i++)
			for(j=0;j<160;j++)
			{
				picH2=gImage_zhaopian[k++];
				picL2=gImage_zhaopian[k++];
				Lcd_WriteData(picH2);
				Lcd_WriteData(picL2);
				
				
			}			
	}	

	delay_ms(3600);			
	
} 


/*void function(void)
{
		Lcd_Clear(GRAY0);
	Gui_DrawLine(5,100,155,100,BLACK);//x��
  Gui_DrawFont_GBK16(150,110,BLACK,GRAY0,"t");
	Gui_DrawFont_GBK16(5,110,BLACK,GRAY0,"0");
	Gui_DrawFont_GBK16(64,110,BLACK,GRAY0,"59");
	Gui_DrawFont_GBK16(124,110,BLACK,GRAY0,"119");
	Gui_DrawLine(5,100,5,0,BLACK);//y��
	Gui_DrawFont_GBK16(5,0,BLACK,GRAY0,"y");
 Gui_Function(5,100, 60);
}
*/
void table(void)
{
/* PC2(ADC12):PowerIn_I
	 PB0(ADC8): PowerIn_U
	 PC3(ADC13):DC5V_I
   PB1(ADC9): DC5V_U
	 PA1(ADC1): DC3.3V_U
	 PA3(ADC3): DC5V*_U
	*/
	//����д��
	/*
	int i;
	for(i=5;i<126;i=i+24)
	{
			Gui_DrawLine(5,i,125,i,BLACK);//����
	}
	for(i=5;i<126;i=i+24)
	{
			Gui_DrawLine(i,5,i,125,BLACK);//����
	}
	*/
  
	
		u16 adc1,adc3,adc8,adc9,adc12,adc13;
	  float temp1,temp3,temp8,temp9,temp13,temp12;
		int i8, i9;
	  int p9,p5;
	  float temppower9,temppower5;
	  u8 e;
		
		u8 r1[]="0";u8 t1[]="0";
	  u8 r3[]="0";u8 t3[]="0";
	  u8 r8[]="0";u8 t8[]="0";
	  u8 r9[]="0";u8 t9[]="0";
		u8 r13[]="0";u8 t13[]="0";
		u8 r12[]="0";u8 t12[]="0";
		u8 rpower9[]="0";u8 tpower9[]="0";
	  u8 rpower5[]="0";u8 tpower5[]="0";
	  u8 re[]="0";u8 te[]="0";
		
		Adc_Init();	//��ʼ��ADC
		BEEP_Init();//��ʼ��������
		RELAY_Init();//��ʼ���̵���
		BEEP=0;//Ĭ�Ϸ������ر�
		RELAY=1;
		
		//����ADCֵ��ʹ���õ�ͨ������ɨ�裬����
		adc1=Get_Adc_Average(ADC_Channel_1 ,10);
		adc3=Get_Adc_Average(ADC_Channel_3 ,10);
		adc8=Get_Adc_Average(ADC_Channel_8 ,10);
		adc9=Get_Adc_Average(ADC_Channel_9 ,10);
		adc13=Get_Adc_Average(ADC_Channel_13 ,10);
		adc12=Get_Adc_Average(ADC_Channel_12 ,10);
		
		//ȡÿһ��ADCֵ���������ֺ͵�һλС������
    temp1=(float)adc1*(3.3/4096);
		adc1=temp1;
		r1[0]=(int)adc1+'0';
		t1[0]=10*(temp1-(int)adc1)+'0';
		
    temp3=(float)adc3*(3.3/4096);
		adc3=temp3;
		r3[0]=(int)adc3+'0';
		t3[0]=10*(temp3-(int)adc3)+'0';
		
		temp8=(float)adc8*(3.3/4096);
		adc8=temp8;
		r8[0]=(int)adc8+'0';
		t8[0]=10*(temp8-(int)adc8)+'0';
		
		temp9=(float)adc9*(3.3/4096);
		adc9=temp9;
		r9[0]=(int)adc9+'0';
		t9[0]=10*(temp9-(int)adc9)+'0';
		

		//��ͷ
		Gui_DrawFont_GBK16(0,5,BLACK,GRAY1,"��Ŀ");
		Gui_DrawFont_GBK16(0,21,BLACK,GRAY1,"      ");
		Gui_DrawFont_GBK16(32,5,BLACK,GRAY1,"��ѹ");
		Gui_DrawFont_GBK16(37,21,BLACK,GRAY1,"U/V ");
		Gui_DrawFont_GBK16(64,5,BLACK,GRAY1,"����");
		Gui_DrawFont_GBK16(69,21,BLACK,GRAY1,"I/A ");
		Gui_DrawFont_GBK16(96,5,BLACK,GRAY1,"����");
		Gui_DrawFont_GBK16(101,21,BLACK,GRAY1,"P/W ");
		Gui_DrawFont_GBK16(128,5,BLACK,GRAY1,"Ч��");
		Gui_DrawFont_GBK16(128,21,BLACK,GRAY1,"��/%");
	 
   //��һ��
   Gui_DrawFont_GBK16(5,40,BLACK,GRAY0,"9V");
	 Gui_DrawFont_GBK16( 5,62,BLACK,GRAY0,"5V");
	 Gui_DrawFont_GBK16(0,84,BLACK,GRAY0,"3.3V");
	 Gui_DrawFont_GBK16(5,106,BLACK,GRAY0,"5V*");
	 
	 //�ڶ���
   Gui_DrawFont_GBK16(36,40,BLACK,RED,r8);
	 Gui_DrawFont_GBK16(44,40,BLACK,RED,".");
	 Gui_DrawFont_GBK16(50,40,BLACK,RED,t8);
	 
	 Gui_DrawFont_GBK16(36,62,BLACK,RED,r9);
	 Gui_DrawFont_GBK16(44,62,BLACK,RED,".");
	 Gui_DrawFont_GBK16(50,62,BLACK,RED,t9);
	 
	 Gui_DrawFont_GBK16(36,84,BLACK,RED,r1);
	 Gui_DrawFont_GBK16(44,84,BLACK,RED,".");
	 Gui_DrawFont_GBK16(50,84,BLACK,RED,t1);
	 
	 Gui_DrawFont_GBK16(36,106,BLACK,RED,r3);
	 Gui_DrawFont_GBK16(44,106,BLACK,RED,".");
	 Gui_DrawFont_GBK16(50,106,BLACK,RED,t3);

	 
	 //������
	 
	 //�������㹫ʽ
	 i8=adc8/adc12;
	 i9=adc9/adc13;
	 
	 	temp12=(float)i8;
		i8=temp12;
		r12[0]=(int)i8+'0';
		t12[0]=10*(temp12-(int)i8)+'0';
		
		temp13=(float)i9;
		i9=temp13;
		r13[0]=(int)i9+'0';
		t13[0]=10*(temp13-(int)i9)+'0';
		
		//��������
		if(i9>1)
		{
			RELAY=0;
			BEEP=1;
		}
		
   Gui_DrawFont_GBK16(68,40,BLACK,RED,r12);
	 Gui_DrawFont_GBK16(76,40,BLACK,RED,".");
	 Gui_DrawFont_GBK16(82,40,BLACK,RED,t12);
	 
	 Gui_DrawFont_GBK16(68,62,BLACK,RED,r13);
	 Gui_DrawFont_GBK16(76,62,BLACK,RED,".");
	 Gui_DrawFont_GBK16(82,62,BLACK,RED,t13);
	 
	 Gui_DrawFont_GBK16(68,84,BLACK,GRAY0,"NA");
	 Gui_DrawFont_GBK16(68,106,BLACK,GRAY0,"NA");
	 
	 //������

		//���㹦��
	 p9=adc8*i8;
	 p5=adc9*i9;
	 
	 temppower9=(float)p9;
	 rpower9[0]=(int)p9+'0';
	 tpower9[0]=10*(temppower9-(int)p9)+'0';
	 
	 temppower5=(float)p5;
	 rpower5[0]=(int)p5+'0';
	 tpower5[0]=10*(temppower5-(int)p5)+'0';
	 
   Gui_DrawFont_GBK16(100,40,BLACK,RED,rpower9);
	 Gui_DrawFont_GBK16(108,40,BLACK,RED,".");
	 Gui_DrawFont_GBK16(114,40,BLACK,RED,tpower9);	
	 
	 Gui_DrawFont_GBK16(100,62,BLACK,RED,rpower5);
	 Gui_DrawFont_GBK16(108,62,BLACK,RED,".");
	 Gui_DrawFont_GBK16(114,62,BLACK,RED,tpower5);
	 
	 Gui_DrawFont_GBK16(100,84,BLACK,GRAY0,"NA");
	 Gui_DrawFont_GBK16(100,106,BLACK,GRAY0,"NA");
	 
	 //������

		temp13=(float)adc1*(3.3/4096);
		adc13=temp13;
		
		e=adc9/adc13;
		
	 re[0]=(int)e+'0';
	 te[0]=10*(e-(int)e)+'0';
	 
   Gui_DrawFont_GBK16(132,40,BLACK,GRAY0,"NA");
	 
	 Gui_DrawFont_GBK16(128,62,BLACK,RED,re);
	 Gui_DrawFont_GBK16(128,62,BLACK,RED,".");
	 Gui_DrawFont_GBK16(128,62,BLACK,RED,te);
	 
	 Gui_DrawFont_GBK16(132,84,BLACK,GRAY0,"NA");
	 Gui_DrawFont_GBK16(132,106,BLACK,GRAY0,"NA");
	//����
		Gui_DrawLine(0,3,160,3,BLACK);//��һ������
	  Gui_DrawLine(0,37,160,37,BLACK);//�ڶ�������
	  Gui_DrawLine(0,59,160,59,BLACK);//����������
	  Gui_DrawLine(0,81,160,81,BLACK);//����������
	  Gui_DrawLine(0,103,160,103,BLACK);//����������
	  Gui_DrawLine(0,125,160,125,BLACK);//����������
	//����
	  Gui_DrawLine(32,3,32,125,BLACK);//�ڶ�������
	  Gui_DrawLine(63,3,63,125,BLACK);//����������
	  Gui_DrawLine(95,3,95,125,BLACK);//����������
	  Gui_DrawLine(127,3,127,125,BLACK);//����������
	  Gui_DrawLine(160,3,160,125,BLACK);//����������
		delay_ms(300);
}
void ninevoltage(int i)
{
	//VOLTAGE
		u16 adc8,adc12;
	  float temp8,temp12;
    int i8;
		
		Adc_Init();	//ADC��ʼ��
		//�������õ�ADC
		adc8=Get_Adc_Average(ADC_Channel_8 ,10);
		adc12=Get_Adc_Average(ADC_Channel_12 ,10);
		
		temp8=(float)adc8*(3.3/4096);
		adc8=temp8;

	  i8=adc8/adc12;
	 	temp12=(float)i8;
		i8=temp12;

		
		
	Gui_DrawFont_GBK16(80,20,BLACK,GRAY0,"9V");
	Gui_DrawLine(10,50,155,50,BLACK);//x��
  Gui_DrawFont_GBK16(135,29,BLACK,GRAY0,"T/s");
	Gui_DrawFont_GBK16(69,52,BLACK,GRAY0,"59");
	Gui_DrawFont_GBK16(115,52,BLACK,GRAY0,"119");
	Gui_DrawLine(10,50,10,0,BLACK);//y��
	Gui_DrawFont_GBK16(20,0,BLACK,GRAY0,"U/V");
	Gui_DrawFont_GBK16(2,45,BLACK,GRAY0,"0");
	Gui_DrawFont_GBK16(2,10,BLACK,GRAY0,"9");
	Gui_DrawPoint(10+i,50-(5*temp8),RED);//����
	//��ͷ
	Gui_DrawLine(10,0,5,5,BLACK);
	Gui_DrawLine(10,0,15,5,BLACK);
	Gui_DrawLine(155,50,147,45,BLACK);
	Gui_DrawLine(155,50,147,55,BLACK);
	
	//CURRENT
	
	Gui_DrawLine(10,110,155,110,BLACK);//x��
  Gui_DrawFont_GBK16(135,89,BLACK,GRAY0,"T/s");
	Gui_DrawFont_GBK16(10,113,BLACK,GRAY0,"0");
	Gui_DrawFont_GBK16(69,113,BLACK,GRAY0,"59");
	Gui_DrawFont_GBK16(115,113,BLACK,GRAY0,"119");
	Gui_DrawLine(10,110,10,65,BLACK);//y��
	Gui_DrawFont_GBK16(20,65,BLACK,GRAY0,"I/A");
	Gui_DrawFont_GBK16(12,90,BLACK,GRAY0,"0.5");
	Gui_DrawFont_GBK16(2,75,BLACK,GRAY0,"1");
	Gui_DrawPoint(10+i,50-(5*temp12),RED);//����
	//��ͷ
	Gui_DrawLine(10,65,5,70,BLACK);
	Gui_DrawLine(10,65,15,70,BLACK);
	Gui_DrawLine(155,110,147,105,BLACK);
	Gui_DrawLine(155,110,147,115,BLACK);
	delay_ms(300);
}

void fivevoltage(int i)
{
		//VOLTAGE
		u16 adc9,adc13;
	  float temp9,temp13;
    int i9;
		
		Adc_Init();//ADC��ʼ��
		//�������õ�ADC	
		adc9=Get_Adc_Average(ADC_Channel_9 ,10);
		adc13=Get_Adc_Average(ADC_Channel_13 ,10);
	
		temp9=(float)adc9*(3.3/4096);
		adc9=temp9;
	
	  i9=adc9/adc13;
	 	temp13=(float)i9;
		i9=temp13;

		
		
	Gui_DrawFont_GBK16(80,20,BLACK,GRAY0,"9V");
	Gui_DrawLine(10,50,155,50,BLACK);//x��
  Gui_DrawFont_GBK16(135,29,BLACK,GRAY0,"T/s");
	Gui_DrawFont_GBK16(69,52,BLACK,GRAY0,"59");
	Gui_DrawFont_GBK16(115,52,BLACK,GRAY0,"119");
	Gui_DrawLine(10,50,10,0,BLACK);//y��
	Gui_DrawFont_GBK16(20,0,BLACK,GRAY0,"U/V");
	Gui_DrawFont_GBK16(2,45,BLACK,GRAY0,"0");
	Gui_DrawFont_GBK16(2,10,BLACK,GRAY0,"9");
	Gui_DrawPoint(10+i,50-(5*temp9),RED);
	Gui_DrawLine(10,0,5,5,BLACK);
	Gui_DrawLine(10,0,15,5,BLACK);
	Gui_DrawLine(155,50,147,45,BLACK);
	Gui_DrawLine(155,50,147,55,BLACK);
	
	//CURRENT
	
	Gui_DrawLine(10,110,155,110,BLACK);//x��
  Gui_DrawFont_GBK16(135,89,BLACK,GRAY0,"T/s");
	Gui_DrawFont_GBK16(10,113,BLACK,GRAY0,"0");
	Gui_DrawFont_GBK16(69,113,BLACK,GRAY0,"59");
	Gui_DrawFont_GBK16(115,113,BLACK,GRAY0,"119");
	Gui_DrawLine(10,110,10,65,BLACK);//y��
	Gui_DrawFont_GBK16(20,65,BLACK,GRAY0,"I/A");
	Gui_DrawFont_GBK16(12,90,BLACK,GRAY0,"0.5");
	Gui_DrawFont_GBK16(2,75,BLACK,GRAY0,"1");
	Gui_DrawPoint(10+i,50-(5*temp13),RED);//����
	//��ͷ
	Gui_DrawLine(10,65,5,70,BLACK);
	Gui_DrawLine(10,65,15,70,BLACK);
	Gui_DrawLine(155,110,147,105,BLACK);
	Gui_DrawLine(155,110,147,115,BLACK);
	delay_ms(300);
}
void LED(void)
{
	  LED0=0;
		delay_ms(150);
		LED0=1;
		delay_ms(150);
}

u16 ID=0;

int main(void)
{
		
	int i=0;
	int flag=0;
	u8 t=0;
  SystemInit();
  delay_init(72);//��ʱ��ʼ��
  Lcd_Init();//��ʼ��Ӳ��SPI
  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2); //���� NVIC �жϷ��� 2
 uart_init(115200); //���ڳ�ʼ��������Ϊ 115200
	LED_Init();
  KEY_Init();
	Adc_Init();		  		//ADC��ʼ��	 

	while(1)
	{
	  
		
	/*}
	
		
//		LCD_LED_SET;//ͨ��IO���Ʊ�����
		/*Name();
		Website();//��Ӣ����ʾ����		
		show_pic();//ͼƬ��ʾʾ��
		show_photo();*/
		//function();
						  //LED();
	t=KEY_Scan(1);
switch(t)
		{
			case KEY0_PRES://���������л�ͼƬ/����
				flag=0;//�����־���������ڻ�ͼ�͹̶���Ļ����
			if(i>1) i=0;		
			else i=i+1;
		  break;
		default: delay_ms(1);
	}
		

	        if(i==0) 
					{
						if(flag==0)
						{
							Lcd_Clear(GRAY0);	
						  Name();
							flag++;
					}
					else table();
				}
		    else if(i==1)
				{
					if(flag==0)
						{
							Lcd_Clear(GRAY0);	
					     ninevoltage(flag);
							flag++;
						}
						else 
						{
							ninevoltage(flag);
							flag++;
						}
				}
		       else 
						{
					   if(flag==0)
						{
							Lcd_Clear(GRAY0);	
							fivevoltage(flag);
							flag++;
						}
						else 	fivevoltage(flag);
						}
//		LCD_LED_CLR;//IO���Ʊ�����		

  }

}


void RCC_Configuration(void)
{   
  /* Setup the microcontroller system. Initialize the Embedded Flash Interface,  
     initialize the PLL and update the SystemFrequency variable. */
  SystemInit();
}


void Delayms(__IO uint32_t nCount)
{
  for(; nCount != 0; nCount--);
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *   where the assert_param error has occurred.
  * @param file: pointer to the source file name
  * @param line: assert_param error line source number
  * @retval : None
  */



void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif



/******************* (C) COPYRIGHT 2009 STMicroelectronics *****END OF FILE****/
